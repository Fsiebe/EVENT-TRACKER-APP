package com.eventtracker.app.ui.notifications

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.eventtracker.app.R
import com.eventtracker.app.databinding.ActivityNotificationSettingsBinding
import com.eventtracker.app.ui.events.EventsActivity
import com.eventtracker.app.ui.login.LoginActivity
import com.eventtracker.app.utils.PreferenceManager
import com.eventtracker.app.utils.SMSManager

class NotificationSettingsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityNotificationSettingsBinding
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var smsManager: SMSManager
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        handlePermissionResult(isGranted)
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        preferenceManager = PreferenceManager(this)
        smsManager = SMSManager(this)
        
        setupToolbar()
        setupClickListeners()
        updatePermissionStatus()
        loadSettings()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.notifications_title)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
    
    private fun setupClickListeners() {
        binding.requestPermissionButton.setOnClickListener {
            requestSmsPermission()
        }
        
        binding.notificationSwitch.setOnCheckedChangeListener { _, isChecked ->
            preferenceManager.setNotificationEnabled(isChecked)
        }
        
        binding.reminderDaysEditText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val days = binding.reminderDaysEditText.text.toString().toIntOrNull() ?: 3
                preferenceManager.setReminderDays(days)
            }
        }
        
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_events -> {
                    startActivity(Intent(this, EventsActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_notifications -> true
                R.id.nav_logout -> {
                    logout()
                    false
                }
                else -> false
            }
        }
        
        // Set notifications as selected
        binding.bottomNavigation.selectedItemId = R.id.nav_notifications
    }
    
    private fun requestSmsPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED -> {
                handlePermissionResult(true)
            }
            shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS) -> {
                // Show rationale and request permission
                Toast.makeText(
                    this,
                    "SMS permission is needed to send event reminders",
                    Toast.LENGTH_LONG
                ).show()
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
            else -> {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        }
    }
    
    private fun handlePermissionResult(isGranted: Boolean) {
        preferenceManager.setSmsPermissionGranted(isGranted)
        updatePermissionStatus()
        
        if (isGranted) {
            Toast.makeText(this, getString(R.string.permission_granted), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updatePermissionStatus() {
        val hasPermission = smsManager.hasPermission()
        preferenceManager.setSmsPermissionGranted(hasPermission)
        
        if (hasPermission) {
            binding.permissionStatusTextView.text = "SMS permission granted ✓"
            binding.permissionStatusTextView.setTextColor(ContextCompat.getColor(this, R.color.success))
            binding.requestPermissionButton.text = "Permission Granted"
            binding.requestPermissionButton.isEnabled = false
        } else {
            binding.permissionStatusTextView.text = "SMS permission required"
            binding.permissionStatusTextView.setTextColor(ContextCompat.getColor(this, R.color.warning))
            binding.requestPermissionButton.text = getString(R.string.grant_permission)
            binding.requestPermissionButton.isEnabled = true
        }
    }
    
    private fun loadSettings() {
        binding.notificationSwitch.isChecked = preferenceManager.isNotificationEnabled()
        binding.reminderDaysEditText.setText(preferenceManager.getReminderDays().toString())
    }
    
    private fun logout() {
        preferenceManager.logout()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}