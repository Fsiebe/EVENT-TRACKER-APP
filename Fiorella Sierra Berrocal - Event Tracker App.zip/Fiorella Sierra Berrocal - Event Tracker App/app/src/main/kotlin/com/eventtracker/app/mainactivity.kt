package com.eventtracker.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.eventtracker.app.ui.login.LoginActivity
import com.eventtracker.app.utils.PreferenceManager

class MainActivity : AppCompatActivity() {
    
    private lateinit var preferenceManager: PreferenceManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        preferenceManager = PreferenceManager(this)
        
        // Check if user is already logged in
        if (preferenceManager.isLoggedIn()) {
            // Navigate to events activity
            navigateToEvents()
        } else {
            // Navigate to login activity
            navigateToLogin()
        }
        
        finish()
    }
    
    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }
    
    private fun navigateToEvents() {
        val intent = Intent(this, com.eventtracker.app.ui.events.EventsActivity::class.java)
        startActivity(intent)
    }
}