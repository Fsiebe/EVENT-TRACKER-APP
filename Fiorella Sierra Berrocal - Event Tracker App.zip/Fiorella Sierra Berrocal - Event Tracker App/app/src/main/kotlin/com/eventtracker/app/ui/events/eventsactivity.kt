package com.eventtracker.app.ui.events

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.eventtracker.app.R
import com.eventtracker.app.data.AppDatabase
import com.eventtracker.app.data.Event
import com.eventtracker.app.databinding.ActivityEventsBinding
import com.eventtracker.app.databinding.DialogAddEventBinding
import com.eventtracker.app.ui.login.LoginActivity
import com.eventtracker.app.ui.notifications.NotificationSettingsActivity
import com.eventtracker.app.utils.PreferenceManager
import com.eventtracker.app.utils.SMSManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class EventsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityEventsBinding
    private lateinit var database: AppDatabase
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var smsManager: SMSManager
    private lateinit var eventsAdapter: EventsAdapter
    private var selectedDate: Date? = null
    private var editingEvent: Event? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        database = AppDatabase.getDatabase(this)
        preferenceManager = PreferenceManager(this)
        smsManager = SMSManager(this)
        
        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        observeEvents()
        
        // Check for upcoming events and send notifications
        checkUpcomingEvents()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.events_title)
    }
    
    private fun setupRecyclerView() {
        eventsAdapter = EventsAdapter(
            onEditClick = { event -> showAddEventDialog(event) },
            onDeleteClick = { event -> showDeleteConfirmation(event) }
        )
        
        binding.eventsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@EventsActivity)
            adapter = eventsAdapter
        }
    }
    
    private fun setupClickListeners() {
        binding.fabAddEvent.setOnClickListener {
            showAddEventDialog()
        }
        
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_events -> true
                R.id.nav_notifications -> {
                    startActivity(Intent(this, NotificationSettingsActivity::class.java))
                    false
                }
                R.id.nav_logout -> {
                    logout()
                    false
                }
                else -> false
            }
        }
        
        // Set events as selected
        binding.bottomNavigation.selectedItemId = R.id.nav_events
    }
    
    private fun observeEvents() {
        val userId = preferenceManager.getCurrentUserId()
        if (userId != -1L) {
            lifecycleScope.launch {
                database.eventDao().getEventsByUser(userId).collect { events ->
                    eventsAdapter.submitList(events)
                    binding.emptyStateTextView.visibility = 
                        if (events.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }
    
    private fun showAddEventDialog(event: Event? = null) {
        val dialogBinding = DialogAddEventBinding.inflate(layoutInflater)
        editingEvent = event
        selectedDate = event?.date
        
        // Pre-fill data if editing
        event?.let {
            dialogBinding.eventNameEditText.setText(it.name)
            dialogBinding.eventDescriptionEditText.setText(it.description)
            dialogBinding.eventDateEditText.setText(
                SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(it.date)
            )
        }
        
        val dialog = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .create()
        
        dialogBinding.eventDateEditText.setOnClickListener {
            showDatePicker { date ->
                selectedDate = date
                dialogBinding.eventDateEditText.setText(
                    SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(date)
                )
            }
        }
        
        dialogBinding.saveButton.setOnClickListener {
            saveEvent(dialogBinding, dialog)
        }
        
        dialogBinding.cancelButton.setOnClickListener {
            dialog.dismiss()
        }
        
        dialog.show()
    }
    
    private fun showDatePicker(onDateSelected: (Date) -> Unit) {
        val calendar = Calendar.getInstance()
        selectedDate?.let { calendar.time = it }
        
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val selectedCalendar = Calendar.getInstance()
                selectedCalendar.set(year, month, dayOfMonth)
                onDateSelected(selectedCalendar.time)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
    
    private fun saveEvent(dialogBinding: DialogAddEventBinding, dialog: AlertDialog) {
        val name = dialogBinding.eventNameEditText.text.toString().trim()
        val description = dialogBinding.eventDescriptionEditText.text.toString().trim()
        
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter event name", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (selectedDate == null) {
            Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show()
            return
        }
        
        lifecycleScope.launch {
            try {
                val userId = preferenceManager.getCurrentUserId()
                
                if (editingEvent != null) {
                    // Update existing event
                    val updatedEvent = editingEvent!!.copy(
                        name = name,
                        description = description,
                        date = selectedDate!!
                    )
                    database.eventDao().updateEvent(updatedEvent)
                    Toast.makeText(this@EventsActivity, "Event updated", Toast.LENGTH_SHORT).show()
                } else {
                    // Create new event
                    val newEvent = Event(
                        userId = userId,
                        name = name,
                        description = description,
                        date = selectedDate!!
                    )
                    database.eventDao().insertEvent(newEvent)
                    Toast.makeText(this@EventsActivity, "Event added", Toast.LENGTH_SHORT).show()
                }
                
                dialog.dismiss()
                editingEvent = null
                selectedDate = null
                
            } catch (e: Exception) {
                Toast.makeText(this@EventsActivity, "Error saving event: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun showDeleteConfirmation(event: Event) {
        AlertDialog.Builder(this)
            .setTitle("Delete Event")
            .setMessage("Are you sure you want to delete '${event.name}'?")
            .setPositiveButton("Delete") { _, _ ->
                deleteEvent(event)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun deleteEvent(event: Event) {
        lifecycleScope.launch {
            try {
                database.eventDao().deleteEvent(event)
                Toast.makeText(this@EventsActivity, "Event deleted", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@EventsActivity, "Error deleting event: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun checkUpcomingEvents() {
        if (!preferenceManager.isNotificationEnabled() || !preferenceManager.isSmsPermissionGranted()) {
            return
        }
        
        lifecycleScope.launch {
            try {
                val userId = preferenceManager.getCurrentUserId()
                val reminderDays = preferenceManager.getReminderDays()
                val currentTime = System.currentTimeMillis()
                val reminderTime = currentTime + (reminderDays * 24 * 60 * 60 * 1000)
                
                val upcomingEvents = database.eventDao().getUpcomingEvents(userId, currentTime)
                
                for (event in upcomingEvents) {
                    if (event.date.time <= reminderTime && event.isNotificationEnabled) {
                        val daysUntil = ((event.date.time - currentTime) / (24 * 60 * 60 * 1000)).toInt()
                        smsManager.sendEventReminder(event.name, daysUntil)
                    }
                }
            } catch (e: Exception) {
                // Handle notification errors silently
            }
        }
    }
    
    private fun logout() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                preferenceManager.logout()
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}