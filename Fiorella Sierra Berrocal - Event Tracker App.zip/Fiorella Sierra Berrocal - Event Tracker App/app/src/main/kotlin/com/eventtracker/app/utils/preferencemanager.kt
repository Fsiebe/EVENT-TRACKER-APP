package com.eventtracker.app.utils

import android.content.Context
import android.content.SharedPreferences

class PreferenceManager(context: Context) {
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    
    companion object {
        private const val PREF_NAME = "event_tracker_prefs"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USERNAME = "username"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_SMS_PERMISSION_GRANTED = "sms_permission_granted"
        private const val KEY_NOTIFICATION_ENABLED = "notification_enabled"
        private const val KEY_REMINDER_DAYS = "reminder_days"
    }
    
    fun setUserLoggedIn(userId: Long, username: String) {
        sharedPreferences.edit()
            .putLong(KEY_USER_ID, userId)
            .putString(KEY_USERNAME, username)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()
    }
    
    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    fun getCurrentUserId(): Long {
        return sharedPreferences.getLong(KEY_USER_ID, -1)
    }
    
    fun getCurrentUsername(): String {
        return sharedPreferences.getString(KEY_USERNAME, "") ?: ""
    }
    
    fun logout() {
        sharedPreferences.edit()
            .remove(KEY_USER_ID)
            .remove(KEY_USERNAME)
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .apply()
    }
    
    fun setSmsPermissionGranted(granted: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_SMS_PERMISSION_GRANTED, granted)
            .apply()
    }
    
    fun isSmsPermissionGranted(): Boolean {
        return sharedPreferences.getBoolean(KEY_SMS_PERMISSION_GRANTED, false)
    }
    
    fun setNotificationEnabled(enabled: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_NOTIFICATION_ENABLED, enabled)
            .apply()
    }
    
    fun isNotificationEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_NOTIFICATION_ENABLED, true)
    }
    
    fun setReminderDays(days: Int) {
        sharedPreferences.edit()
            .putInt(KEY_REMINDER_DAYS, days)
            .apply()
    }
    
    fun getReminderDays(): Int {
        return sharedPreferences.getInt(KEY_REMINDER_DAYS, 3)
    }
}