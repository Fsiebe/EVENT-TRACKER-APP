package com.eventtracker.app.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

class SMSManager(private val context: Context) {
    
    private val smsManager = SmsManager.getDefault()
    
    fun hasPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    fun sendEventReminder(eventName: String, daysUntil: Int) {
        if (!hasPermission()) {
            return
        }
        
        try {
            val message = when {
                daysUntil == 0 -> "Event today: $eventName"
                daysUntil == 1 -> "Event tomorrow: $eventName"
                else -> "Upcoming event: $eventName in $daysUntil days"
            }
            
            // In a real app, you would send to the user's phone number
            // For demo purposes, we'll just log or show a notification
            // smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            
        } catch (e: Exception) {
            // Handle SMS sending errors
        }
    }
    
    fun sendTestMessage(message: String, phoneNumber: String) {
        if (!hasPermission()) {
            return
        }
        
        try {
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        } catch (e: Exception) {
            // Handle SMS sending errors
        }
    }
}