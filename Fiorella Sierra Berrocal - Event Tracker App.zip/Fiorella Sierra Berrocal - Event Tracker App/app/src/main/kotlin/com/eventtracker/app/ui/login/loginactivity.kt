package com.eventtracker.app.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.eventtracker.app.R
import com.eventtracker.app.data.AppDatabase
import com.eventtracker.app.data.User
import com.eventtracker.app.databinding.ActivityLoginBinding
import com.eventtracker.app.ui.events.EventsActivity
import com.eventtracker.app.utils.PreferenceManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityLoginBinding
    private lateinit var database: AppDatabase
    private lateinit var preferenceManager: PreferenceManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        database = AppDatabase.getDatabase(this)
        preferenceManager = PreferenceManager(this)
        
        setupClickListeners()
    }
    
    private fun setupClickListeners() {
        binding.loginButton.setOnClickListener {
            performLogin()
        }
        
        binding.createAccountButton.setOnClickListener {
            createAccount()
        }
    }
    
    private fun performLogin() {
        val username = binding.usernameEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString().trim()
        
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }
        
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val user = database.userDao().login(username, password)
                if (user != null) {
                    preferenceManager.setUserLoggedIn(user.id, user.username)
                    navigateToEvents()
                } else {
                    showLoading(false)
                    Toast.makeText(this@LoginActivity, getString(R.string.login_error), Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                showLoading(false)
                Toast.makeText(this@LoginActivity, "Login failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun createAccount() {
        val username = binding.usernameEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString().trim()
        
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (password.length < 4) {
            Toast.makeText(this, "Password must be at least 4 characters", Toast.LENGTH_SHORT).show()
            return
        }
        
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val existingUser = database.userDao().getUserByUsername(username)
                if (existingUser != null) {
                    showLoading(false)
                    Toast.makeText(this@LoginActivity, getString(R.string.username_exists), Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                val newUser = User(username = username, password = password)
                val userId = database.userDao().insertUser(newUser)
                
                preferenceManager.setUserLoggedIn(userId, username)
                Toast.makeText(this@LoginActivity, getString(R.string.account_created), Toast.LENGTH_SHORT).show()
                navigateToEvents()
                
            } catch (e: Exception) {
                showLoading(false)
                Toast.makeText(this@LoginActivity, "Account creation failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.loginButton.isEnabled = !show
        binding.createAccountButton.isEnabled = !show
        binding.usernameEditText.isEnabled = !show
        binding.passwordEditText.isEnabled = !show
    }
    
    private fun navigateToEvents() {
        val intent = Intent(this, EventsActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}