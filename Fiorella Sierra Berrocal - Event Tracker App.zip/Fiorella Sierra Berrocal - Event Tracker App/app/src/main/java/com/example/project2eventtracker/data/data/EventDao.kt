package com.eventtracker.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM events WHERE userId = :userId ORDER BY date ASC")
    fun getEventsByUser(userId: Long): Flow<List<Event>>
    
    @Insert
    suspend fun insertEvent(event: Event): Long
    
    @Update
    suspend fun updateEvent(event: Event)
    
    @Delete
    suspend fun deleteEvent(event: Event)
    
    @Query("SELECT * FROM events WHERE id = :eventId")
    suspend fun getEventById(eventId: Long): Event?
    
    @Query("SELECT * FROM events WHERE userId = :userId AND date >= :currentDate ORDER BY date ASC")
    suspend fun getUpcomingEvents(userId: Long, currentDate: Long): List<Event>
}